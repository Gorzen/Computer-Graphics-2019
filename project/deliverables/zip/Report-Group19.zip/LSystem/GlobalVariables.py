class vars:
  points = []
  twisted_points = []
  symbols = []
  twisted = False
