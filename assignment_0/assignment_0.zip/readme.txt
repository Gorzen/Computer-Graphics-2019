A very nice color!
